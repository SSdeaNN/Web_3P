
function numMayor(){
let numeros = [];

while (true) {
    let input = prompt("Ingresa un número");
    if (input === null) {
        if (numeros.length > 0) {
            let numeroGrande = Math.max(...numeros);
            alert("El número más grande ingresado es " + numeroGrande);
        }
        break;
    }
    let numero = parseFloat(input);
    if (!isNaN(numero)) {
        numeros.push(numero);
    }
  }
}
numMayor();

    function esPalindromo(palabra) {
    palabra = palabra.replace(/\s/g, '').toLowerCase();

    let reverso = palabra.split('').reverse().join('');
    return palabra === reverso;
        }
      function palíndromo(){
        let palabra = prompt("Ingresa una palabra o frase");
        if (esPalindromo(palabra)) {
            alert("La palabra frase es un palíndromo");
        } else {
            alert("La palabra frase no es un palíndromo");
        }
      }    
esPalindromo();

function sumardigitos(){
    const numero = prompt("Ingrese un número:"); 
        let suma = 0;  

    for (let i = 0; i < numero.length; i++) {
      suma += parseInt(numero.charAt(i));
    }
  
    alert("La suma es " +suma);
  
  }
  sumardigitos();

  function generarNumeroAleatorio() {
    let rangoMin = parseInt(prompt("Ingresa el límite inferior del rango"));
let rangoMax = parseInt(prompt("Ingresa el límite superior del rango"));

if (!isNaN(rangoMin) && !isNaN(rangoMax)) {
    let numeroAleatorio = Math.floor(Math.random() * (rangoMax - rangoMin + 1)) + rangoMin;
    alert("El número aleatorio dentro del rango es: " + numeroAleatorio);
}
  }

  function generarSecuenciaFibonacci() {
      const numero = parseInt(prompt("Ingrese un número:")); 
      let secuencia = [0, 1];  
    
    
      for (let i = 2; secuencia[i - 1] + secuencia[i - 2] <= numero; i++) {
        secuencia[i] = secuencia[i - 1] + secuencia[i - 2];
      }
    
     alert("La secuencia de Fibonacci es "+numero +" es: " +secuencia.join(", "));
    
    }
