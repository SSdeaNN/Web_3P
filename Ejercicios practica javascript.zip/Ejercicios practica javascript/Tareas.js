function getAge(){
 var years = prompt("enter your age");
 if (parseInt(years) >= 18){
    alert("you can drive now baby");
 }else{
    alert("you can't drive baby");
 }
}

getAge();

function getQualitification(){
   var Qualitification = prompt("Enter your qualification (0-10)");
      if (Qualitification >= 0 && Qualitification < 3) {
         alert("Very poor");
       } else if (Qualitification >= 3 && Qualitification < 5) {
         alert("Insufficient");
       } else if (Qualitification >= 5 && Qualitification < 6) {
         alert("Enough");
       } else if (Qualitification >= 6 && Qualitification < 7) {
         alert("Nice");
       } else if (Qualitification >= 7 && Qualitification < 9) {
         alert("Remarkable");
       } else if (Qualitification >= 9 && Qualitification <= 10) {
         alert("Outstanding");
       } else {
   }
}
getQualitification();

function chain(){
var chain = [];

while(true){
   var text = prompt("enter text: ");
      if(text === null){
      break;
   }
    chain.push(text);
   }
   
   var print = chain.join("-");
   alert("text form of chain: " + print);
}

chain();

function dniNumber(){

   while (true) {
      var typeNumber = prompt("enter your number of DNI:");
           
      if (typeNumber === null) {
        break;
      }
           
      var number = parseInt(typeNumber);
           
      if (isNaN(number)) {
        alert("this value is not a valid number");
        continue;
      }
           
      if (number < 0 || number > 99999999) {
        alert("this ID number must be between 0 and 99999999");
        continue;
      }
           
      var letters = "TRWAGMYFPDXBNJZSQVHLCKE";
      var first = number % 23;
      var letters = letthers.charAt(first);
           
      alert("this letters DNI " + number + " is: " + letters);
       }
}

dniNumber();

